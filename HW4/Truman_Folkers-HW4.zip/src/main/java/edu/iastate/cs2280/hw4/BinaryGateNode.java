package edu.iastate.cs2280.hw4;

public abstract class BinaryGateNode extends GateNode {

	
	public BinaryGateNode(Node left, Node right) {
		super(left, right);
	}
	
	
}
