package edu.iastate.cs2280.hw4;

public abstract class UnaryGateNode extends GateNode {
	
	
	public UnaryGateNode(Node left, Node right) {
		super(left, right);
	}
	
	
	
}
